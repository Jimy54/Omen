import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branch-office-inventary-edit',
  templateUrl: './branch-office-inventary-edit.component.html',
  styleUrls: ['./branch-office-inventary-edit.component.css']
})
export class BranchOfficeInventaryEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
