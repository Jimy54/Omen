export class Employer {
  constructor(
    public EmployeeID: string,
    public EmployeeName,
    public EmployerPhone,
    public EmployeeAddress,
    public EmployeeEmail,
    public EmployeeAge,
    public EmployeeSalary,
    public EmployeeContration,
    public EmployeeRol,
    public EmployeeUser,
    public EmployeePassword,
    public BranchOfficeID,
    public BusinessID
  ) {}
}
