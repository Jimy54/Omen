export class Business {
  constructor(
    private BusinessName: string,
    private BusinessCountry: string,
    private BusinessLogo: string,
    private UserID: number
  ) {}
}
