export interface Inventary {
  InventaryID;
  InventaryDescription;
  Quantity;
  Tax;
  InventaryImage;
  CodeBar;
  BusinessID;
  CategoryID;
}
