export class Purchase {
  constructor(
    private PurchaseID: string,
    private Date: string,
    private Total: string,
    private ProviderID: string,
    private BusinessID: number
  ) {}
}
