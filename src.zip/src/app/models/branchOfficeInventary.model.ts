export interface BranchOfficeInventary {
  BranchOfficeInventaryID;
  Description;
  Quantity;
  CodeBar;
  BusinessID;
  InventaryID;
  BranchOfficeID;
}
