export interface Provider {
  ProviderID;
  ProviderName;
  ProviderAddress;
  ProviderPhone;
  ProviderEmail;
  BusinessID;
}
