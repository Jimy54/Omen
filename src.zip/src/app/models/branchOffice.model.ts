export interface BranchOffice {
  BranchOfficeID;
  BranchOfficeName;
  BranchOfficeAddress;
  BranchOfficePhone;
  BusinessID;
}
