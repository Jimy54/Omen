import { Component, OnInit } from "@angular/core";
import { BranchOfficeComponent } from "../branch-office/branch-office.component";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: "app-branch-office-add",
  templateUrl: "./branch-office-add.component.html",
  styleUrls: ["./branch-office-add.component.css"]
})
export class BranchOfficeAddComponent implements OnInit {
  constructor(private dialogRef: MatDialogRef<BranchOfficeComponent>) {}

  ngOnInit() {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
