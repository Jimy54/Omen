import { Component, OnInit } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material";
import { BranchOfficeAddComponent } from "../branch-office-add/branch-office-add.component";
@Component({
  selector: "app-branch-office",
  templateUrl: "./branch-office.component.html",
  styleUrls: ["./branch-office.component.css"]
})
export class BranchOfficeComponent implements OnInit {
  constructor(private dialog: MatDialog) {}

  ngOnInit() {}

  EnterDialog(): void {
    let dialogRef = this.dialog.open(BranchOfficeAddComponent, {
      width: "800px",
      height: "400px",
      data: {}
    });

    dialogRef.afterClosed().subscribe(result => {});
  }
}
