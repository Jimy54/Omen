import { Component, OnInit } from "@angular/core";
import { FormControl, Validators } from "@angular/forms";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material";
import { ProviderAddComponent } from "../provider-add/provider-add.component";

@Component({
  selector: "app-providers",
  templateUrl: "./providers.component.html",
  styleUrls: ["./providers.component.css"]
})
export class ProvidersComponent implements OnInit {
  constructor(public dialog: MatDialog) {}

  ngOnInit() {}

  EnterDialog(): void {
    let dialogRef = this.dialog.open(ProviderAddComponent, {
      width: "700px",
      height: "400px",
      data: {}
    });

    dialogRef.afterClosed().subscribe(result => {});
  }
}
