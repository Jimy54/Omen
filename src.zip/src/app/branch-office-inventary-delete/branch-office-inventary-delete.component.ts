import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branch-office-inventary-delete',
  templateUrl: './branch-office-inventary-delete.component.html',
  styleUrls: ['./branch-office-inventary-delete.component.css']
})
export class BranchOfficeInventaryDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
