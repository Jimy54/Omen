import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { OverlayContainer } from "@angular/cdk/overlay";
import { HttpClientModule } from "@angular/common/http";

//Components
import { AppComponent } from "./app.component";
import { EmployersComponent } from "./employers/employers.component";

//Angular Material
import { MatDialogModule } from "@angular/material/dialog";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { FlexLayoutModule } from "@angular/flex-layout";
import { MatInputModule } from "@angular/material/input";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatNativeDateModule } from "@angular/material";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatTableModule } from "@angular/material/table";
import { MatSelectModule } from "@angular/material/select";
import { MatCardModule } from "@angular/material/card";
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from "@angular/material/core";
import { MatButtonModule } from "@angular/material/button";
import { MatDividerModule } from "@angular/material/divider";
import { MatSnackBarModule } from "@angular/material/snack-bar";
import { MatToolbarModule } from "@angular/material/toolbar";
//Routes
import { routing } from "./app.routing";
import { ProvidersComponent } from "./providers/providers.component";
import { MovesComponent } from "./moves/moves.component";
import { BusinessComponent } from "./business/business.component";
import { MenuComponent } from "./menu/menu.component";
import { EmployerAddComponent } from "./employer-add/employer-add.component";
import { ProviderAddComponent } from "./provider-add/provider-add.component";
import { MoveAddComponent } from "./move-add/move-add.component";
import { BranchOfficeComponent } from "./branch-office/branch-office.component";
import { BranchOfficeAddComponent } from "./branch-office-add/branch-office-add.component";
import { InventariesComponent } from "./inventaries/inventaries.component";
import { InventaryAddComponent } from "./inventary-add/inventary-add.component";
import { CategoryComponent } from "./category/category.component";
import { CategoryAddComponent } from "./category-add/category-add.component";

//Themes Angular

@NgModule({
  declarations: [
    AppComponent,
    EmployersComponent,
    ProvidersComponent,
    MovesComponent,
    BusinessComponent,
    MenuComponent,
    EmployerAddComponent,
    ProviderAddComponent,
    MoveAddComponent,
    BranchOfficeComponent,
    BranchOfficeAddComponent,
    InventariesComponent,
    InventaryAddComponent,
    CategoryComponent,
    CategoryAddComponent
  ],
  imports: [
    BrowserModule,
    routing,
    BrowserAnimationsModule,
    HttpClientModule,
    MatInputModule,
    FlexLayoutModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatCardModule,
    MatToolbarModule,
    MatButtonModule,
    MatDialogModule,
    MatDatepickerModule,
    MatTableModule,
    MatDividerModule,
    MatSelectModule,
    MatDialogModule,
    FormsModule,
    ReactiveFormsModule,
    MatNativeDateModule
  ],
  providers: [{ provide: MAT_DATE_LOCALE, useValue: "es-ES" }],
  bootstrap: [AppComponent],

  entryComponents: [
    EmployerAddComponent,
    ProviderAddComponent,
    MoveAddComponent,
    BranchOfficeAddComponent,
    InventaryAddComponent,
    CategoryAddComponent
  ]
})
export class AppModule {
  constructor(overlayContainer: OverlayContainer) {
    overlayContainer.getContainerElement().classList.add("app-dark-theme");
  }
}
