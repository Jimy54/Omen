export interface Employer {
  EmployeeID;
  EmployeeName;
  EmployerPhone;
  EmployeeAddress;
  EmployeeEmail;
  EmployeeAge;
  EmployeeSalary;
  EmployeeContration;
  EmployeeRol;
  EmployeeUser;
  EmployeePassword;
  BranchOfficeID;
  BusinessID;
}
