export interface Category {
  CategoryID;
  CategoryDescription;
  BusinessID;
}
