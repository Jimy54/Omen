export class Users {
  constructor(
    public UserID: string,
    public UserName: string,
    public UserNickName: string,
    public UserEmail: string,
    public UserPassword: string
  ) {}
}
