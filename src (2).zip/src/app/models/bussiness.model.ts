export interface Business {
  BusinessName;
  BusinessCountry;
  BusinessLogo;
  UserID;
}
