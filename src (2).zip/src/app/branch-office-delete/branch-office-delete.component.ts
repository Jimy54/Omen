import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branch-office-delete',
  templateUrl: './branch-office-delete.component.html',
  styleUrls: ['./branch-office-delete.component.scss']
})
export class BranchOfficeDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
