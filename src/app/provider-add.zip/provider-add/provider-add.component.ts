import { Component, OnInit, Provider } from "@angular/core";
import { FormControl, Validators } from "@angular/forms";
import { ProvidersComponent } from "../providers/providers.component";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

const emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
@Component({
  selector: "app-provider-add",
  templateUrl: "./provider-add.component.html",
  styleUrls: ["./provider-add.component.css"]
})
export class ProviderAddComponent implements OnInit {
  constructor(private dialogRef: MatDialogRef<ProvidersComponent>) {}
  ProviderName;
  ProviderAddress;
  ProviderPhone;
  ProviderEmail;
  BusinessID;

  ngOnInit() {}

  emailFormControl = new FormControl("", [
    Validators.required,
    Validators.pattern(emailPattern)
  ]);

  onNoClick(): void {
    this.dialogRef.close();
  }
}
