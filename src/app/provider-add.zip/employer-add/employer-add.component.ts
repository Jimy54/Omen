import { Component, OnInit, Inject } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { HttpClient } from "@angular/common/http";
import { EmployersComponent } from "../employers/employers.component";
import { Router, NavigationStart } from "@angular/router";
import { FormControl, Validators, FormGroup } from "@angular/forms";
import { FormBuilder } from "@angular/forms";

const emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
@Component({
  selector: "app-employer-add",
  templateUrl: "./employer-add.component.html",
  styleUrls: ["./employer-add.component.css"]
})
export class EmployerAddComponent implements OnInit {
  hide: true;
  EmployerName;
  EmployerPhone;
  EmployerAddress;
  EmployerEmail;
  EmployerAge;
  EmployerSalary;
  EmployerContration;
  EmployerRol;
  EmployerUser;
  EmployerPassword;
  BranchOfficeID;
  BussinessID;
  fbRegistrer: FormGroup;

  constructor(
    private fb: FormBuilder,
    public httpCliente: HttpClient,
    private dialogRef: MatDialogRef<EmployersComponent>
  ) {
    this.fbRegistrer = this.fb.group({
      emailFormControl: [
        "",
        [Validators.required, Validators.pattern(emailPattern)]
      ],

      userFormControl: ["", Validators.required],
      passFormControl: ["", Validators.required]
    });

    this.EmployerEmail = this.fbRegistrer.controls["emailFormControl"];
    this.EmployerPassword = this.fbRegistrer.controls["passFormControl"];
    this.EmployerUser = this.fbRegistrer.controls["userFormControl"];
  }

  ngOnInit() {}

  enterEmployer() {
    console.log(this.EmployerName);
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
