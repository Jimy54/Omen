import { Component, OnInit } from "@angular/core";
import { Title } from "@angular/platform-browser";
import { Router, NavigationStart } from "@angular/router";
import { FormControl, Validators, FormGroup } from "@angular/forms";
import { FormBuilder } from "@angular/forms";
import { EmployerAddComponent } from "../employer-add/employer-add.component";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material";

const emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
@Component({
  selector: "app-employers",
  templateUrl: "./employers.component.html",
  styleUrls: ["./employers.component.css"]
})
export class EmployersComponent implements OnInit {
  constructor(public dialog: MatDialog) {}

  ngOnInit() {}

  EnterDialog(): void {
    let dialogRef = this.dialog.open(EmployerAddComponent, {
      width: "1000px",
      height: "600px",
      data: {}
    });

    dialogRef.afterClosed().subscribe(result => {});
  }
}
